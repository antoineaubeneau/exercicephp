<?php
try {
    $db = new PDO(
        'mysql:host=localhost;dbname=todos;charset=utf8',
        'root',
        'root',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
};

$sql = 'SELECT * FROM todo';

$todoStmt = $db->prepare($sql);
$todoStmt->execute();

$elements = $todoStmt->fetchAll();


?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> To Do List AUBENEAU</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
</head>

<body>
    <div class="container">

        <div class="row mt-3">
            <div class="col offest -2">
                <h1>TO DO LIST</h1>
            </div>
        </div>

        <form action="udapte.php" method="POST" class="row mt-3" id="addTask">

            <input type="hidden" name="action" value="add_task">

            <div class="col -4">
                <a href="create.php" class="btn btn-primary mb-3">Ajouter</a>
            </div>

        </form>

        <div class="row">
            <div class="col -7 offset -2">
                <table class="table table-bordered table-striped table-hover">
                    <thead>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Contenu</th>
                        <th>Done</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php foreach ($elements as $todo) : ?>
                            <tr>
                                <td style="width: 10%" input="checkbox" class="form-check-input"> <?= $todo['id'] ?></td>
                                <td style="width: 10%" input="checkbox" class="form-check-input"> <?= $todo['name'] ?></td>
                                <td style="width: 10%" input="checkbox" class="form-check-input"> <?= $todo['content'] ?></td>
                                <td style="width: 10%" input="checkbox" class="form-check-input"> <?= $todo['done'] == true ? "Terminer" : "En cours" ?></td>
                                <td>
                                    <a href="update.php?id=<?= $todo['id'] ?> name=<?= $todo['name'] ?> content=<?= $todo['content'] ?>" class="btn btn-success mb-2">Modifier</a>
                                    <a href="delete.php?id=<?= $todo['id'] ?>" class="btn btn-danger mb-2">Supprimer</a>
                                    <a href="update_status.php?id=<?= $todo['id'] ?>" class="btn btn-warning mb-2">Terminer</a>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>


    </div>

</body>

</html>