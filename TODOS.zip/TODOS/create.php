<?php
try {
    $db = new PDO(
        'mysql:host=localhost;dbname=todos;charset=utf8',
        'root',
        'root',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
};

if (!empty($_POST)) {
    if (isset($_POST['name']) && isset($_POST['content'])) {


        $name = $_POST['name'];
        $content = $_POST['content'];
        $sql = 'INSERT INTO todo (name, content) VALUES ( "' . $name . '", "' . $content . '")';
        $todoStmt = $db->prepare($sql);
        $todoStmt = $db->prepare($sql);
        $todoStmt->execute();


        header("Location: index.php");
        exit();
    } else {
        echo 'Veuillez renseigner tous les champs';
    }
}


?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ajouter une tache</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
</head>

<body>

    <div class="container">

        <div class="row mt-3">
            <div class="col offest -2">
                <h1>Ajouter une tache</h1>
            </div>
        </div>

        <form action="create.php" method="POST" class="row mt-3" id="addTask">

            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Nom de la tâche : </span>
                <input type="text" name="name" class="form-control">
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Message : </span>
                <input type="text" name="content" class="form-control">
            </div>

            <div class="col -4">
                <button type="submit" class="btn btn-primary mb-3">Ajouter</button>
            </div>

        </form>

</body>

</html>