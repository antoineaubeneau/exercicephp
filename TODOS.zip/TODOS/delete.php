<?php
try {
    $db = new PDO(
        'mysql:host=localhost;dbname=todos;charset=utf8',
        'root',
        'root',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
};

if (!empty($_GET)) {
    if (isset($_GET['id'])) {

        $id = strip_tags($_GET['id']);
        $sql = 'DELETE FROM `todo` WHERE id = ' . $id;
        $todoStmt = $db->prepare($sql);
        $todoStmt = $db->prepare($sql);
        $todoStmt->execute();


        header("Location: index.php");
        exit();
    } else {
        echo 'Veuillez renseigner tous les champs';
    }
}
