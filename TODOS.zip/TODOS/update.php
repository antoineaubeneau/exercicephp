<?php
try {
    $db = new PDO(
        'mysql:host=localhost;dbname=todos;charset=utf8',
        'root',
        'root',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
};



if (!empty($_POST)) {
    if (isset($_POST['submit']) && isset($_POST['content'])) {

        $id = strip_tags($_GET['id']);
        $name = strip_tags($_POST['name']);
        $content = strip_tags($_POST['content']);
        $sql = 'UPDATE todo SET name =:name, content = :content  WHERE id = :id';
        $todoStmt = $db->prepare($sql);
        $todoStmt->execute();
        header("Location: index.php");
        exit([
            'name' => $name,
            'content' => $content,
            'id' => $id,
        ]);
    } else {
        echo 'Veuillez renseigner tous les champs';
    }
}



?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Modifier une tache</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
</head>

<body>

    <div class="container">

        <div class="row mt-3">
            <div class="col offest -2">
                <h1>Modifier une tache</h1>
            </div>
        </div>

        <form method="POST" class="row mt-3" id="addTask">

            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Nom de la tâche :</span>
                <input type="text" id="name" name="name" value="<?= $_GET['name'] ?>">
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Message : </span>
                <input type="text" id="content" name="content" value="<?= $_GET['content'] ?>">
            </div>

            <div class="col -4">
                <button name="submit" type="submit" class="btn btn-primary mb-3">Modifier</button>
            </div>

        </form>

    </div>

</body>

</html>