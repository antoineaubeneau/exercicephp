<?php
try {
    $db = new PDO(
        'mysql:host=localhost;dbname=todos;charset=utf8',
        'root',
        'root',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
};


if (!empty($_GET)) {
    if (isset($_GET['id'])) {


        $id = strip_tags($_GET['id']);
        $sql = "SELECT done FROM todo WHERE id = :id";
        $todosStmt = $db->prepare($sql);
        $todosStmt->bindParam(':id', $id, PDO::PARAM_STR);
        $todosStmt->execute();
        $todos = $todosStmt->fetchAll();

        $done = $todos[0]['done'] == true ? 0 : 1;

        $sql = "UPDATE todo SET done = :done WHERE id = :id";
        $todosStmt = $db->prepare($sql);
        $todosStmt->bindParam(':id', $id, PDO::PARAM_STR);
        $todosStmt->bindParam(':done', $done, PDO::PARAM_STR);
        $todosStmt->execute();

        header("Location: index.php");
        exit();
    }
}
